%figure(2);
df=667;

for fre=0.01:0.01:0.25
 j=1;
 for p=1000:500:10^5
 
 pc=p*fre;
 pd=p*(1-fre);

 pc1 = double(pc/df);
 pd1 = double(pd/df);
 
  for i=1:1:100
   [t,x]=ode23(@separatrix_equ2,[0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10,10.5,11,11.5,12,12.5,13,13.5,14,14.5,15,15.5,16,16.5,17,17.5,18,18.5,19,19.5,20,20.5],[pc1;pd1]);
   w=x(:,1);
   z=x(:,2);
   if w(42)<276
    pc2=double(w(42)/df);
    pd2=double(z(42)/df);
    p2=w(42)+z(42);
   else
    for k=1:1:41
      if w(k)<276 && w(k+1)>276
        t0=(k-1)*0.5+0.5*(276-w(k))/(w(k+1)-w(k));
        pc2=276;
        pd2=z(k)+(z(k+1)-z(k))*(276-w(k))/(w(k+1)-w(k));
        break
      end
    end
    [t,x]=ode23(@separatrix_equ1,[0,20.5-t0],[pc2;pd2]);
    ww=x(:,1);
    zz=x(:,2);
    pc2=vpa(ww(end),10);
    pd2=vpa(zz(end),10);
    pc2 = double(pc2/df);
    pd2 = double(pd2/df);
    p2=ww(end)+zz(end);
   end
   pc1=pc2;
   pd1=pd2;
  end
 P2(j)=p2;
 Fre_stable(j)=pc2/(pc2+pd2);
 j=j+1;
 end

q=int8(fre/0.01); 
 if P2(199)<100
      Separatrix(q)=10^5;
 else
     for l=1:1:198
     if P2(l)<100 && P2(l+1)>50000
      Separatrix(q)=1000+500*l-250;
     break
     end
     end
 end
 
end


for fre=0.26:0.01:1
 j=1;
 for p=100:50:2000

 pc=p*fre;
 pd=p*(1-fre);

 pc1 = double(pc/df);
 pd1 = double(pd/df);
 
  for i=1:1:100
   [t,x]=ode23(@separatrix_equ2,[0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10,10.5,11,11.5,12,12.5,13,13.5,14,14.5,15,15.5,16,16.5,17,17.5,18,18.5,19,19.5,20,20.5],[pc1;pd1]);
   w=x(:,1);
   z=x(:,2);
   if w(42)<276
    pc2=double(w(42)/df);
    pd2=double(z(42)/df);
    p2=w(42)+z(42);
   else
    for k=1:1:41
      if w(k)<276 && w(k+1)>276
        t0=(k-1)*0.5+0.5*(276-w(k))/(w(k+1)-w(k));
        pc2=276;
        pd2=z(k)+(z(k+1)-z(k))*(276-w(k))/(w(k+1)-w(k));
        break
      end
    end
    [t,x]=ode23(@separatrix_equ1,[0,20.5-t0],[pc2;pd2]);
    ww=x(:,1);
    zz=x(:,2);
    pc2=vpa(ww(end),10);
    pd2=vpa(zz(end),10);
    pc2 = double(pc2/df);
    pd2 = double(pd2/df);
    p2=ww(end)+zz(end);
   end
   pc1=pc2;
   pd1=pd2;
  end
 P2(j)=p2;
 Fre_stable(j)=pc2/(pc2+pd2);
 j=j+1;
 end

 q = int8(fre/0.01);
 for l=1:1:38
     if P2(l)<100 && P2(l+1)>50000
         Separatrix(q)=100+50*l-25;
     break
     end
 end

end

save('SeparatrixSolution.mat','Separatrix');

for i=1:1:100
    A(i,1)=i*0.01;
    A(i,2)=Separatrix(i);
end

fid=fopen('/Users/wangxin/Desktop/code for stable manifold/SeparatrixSolution.txt','wt');%写入文件路径
[m,n]=size(A);
 for i=1:1:m
    for j=1:1:n
       if j==n
         fprintf(fid,'%g\n',A(i,j));
      else
        fprintf(fid,'%g\t',A(i,j));
       end
    end
end
fclose(fid);



