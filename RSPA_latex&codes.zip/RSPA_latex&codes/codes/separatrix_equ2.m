function dx=separatrix_equ2(t,x) 
dx=zeros(2,1); 
dx(1)=0.31*x(1)*(1-((x(1)+x(2))/83341));
dx(2)=0.925*0.31*x(2)*((1-(x(1)+x(2))/83341));
end